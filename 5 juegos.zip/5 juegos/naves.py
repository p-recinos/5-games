import pygame
import random
import math
import sys
from pygame.locals import *

# Inicializar Pygame
pygame.init()
pygame.font.init()
pygame.mixer.init()

# Constantes
WIDTH = 800
HEIGHT = 600
FPS = 60

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 50, 50)
GREEN = (50, 255, 50)
BLUE = (50, 50, 255)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)

# Configuración de la pantalla
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Defensor Espacial - 10 Niveles")
clock = pygame.time.Clock()

# Fuentes
font_small = pygame.font.SysFont('Arial', 20)
font_medium = pygame.font.SysFont('Arial', 30)
font_large = pygame.font.SysFont('Arial', 50)

# Clase Jugador
class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((50, 40))
        self.image.fill(GREEN)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 0
        self.speedy = 0
        self.shield = 100
        self.shoot_delay = 250
        self.last_shot = pygame.time.get_ticks()
        self.lives = 3
        self.hidden = False
        self.hide_timer = pygame.time.get_ticks()
        self.power = 1
        self.power_timer = pygame.time.get_ticks()

    def update(self):
        # Mostrar después de muerte
        if self.hidden and pygame.time.get_ticks() - self.hide_timer > 1000:
            self.hidden = False
            self.rect.centerx = WIDTH / 2
            self.rect.bottom = HEIGHT - 10

        # Tiempo de powerup
        if self.power >= 2 and pygame.time.get_ticks() - self.power_timer > 5000:
            self.power -= 1
            self.power_timer = pygame.time.get_ticks()

        # Movimiento
        self.speedx = 0
        self.speedy = 0
        keystate = pygame.key.get_pressed()
        if keystate[pygame.K_LEFT]:
            self.speedx = -8
        if keystate[pygame.K_RIGHT]:
            self.speedx = 8
        if keystate[pygame.K_UP]:
            self.speedy = -8
        if keystate[pygame.K_DOWN]:
            self.speedy = 8
        if keystate[pygame.K_SPACE]:
            self.shoot()

        # Límites de pantalla
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT

    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_shot > self.shoot_delay and not self.hidden:
            self.last_shot = now
            if self.power == 1:
                bullet = Bullet(self.rect.centerx, self.rect.top)
                all_sprites.add(bullet)
                bullets.add(bullet)
            elif self.power >= 2:
                bullet1 = Bullet(self.rect.left, self.rect.top)
                bullet2 = Bullet(self.rect.right, self.rect.top)
                all_sprites.add(bullet1)
                all_sprites.add(bullet2)
                bullets.add(bullet1)
                bullets.add(bullet2)
                if self.power >= 3:
                    bullet3 = Bullet(self.rect.centerx, self.rect.top)
                    all_sprites.add(bullet3)
                    bullets.add(bullet3)

    def powerup(self):
        self.power += 1
        self.power_timer = pygame.time.get_ticks()

    def hide(self):
        self.hidden = True
        self.hide_timer = pygame.time.get_ticks()
        self.rect.center = (WIDTH / 2, HEIGHT + 200)

# Clase Enemigo
class Enemy(pygame.sprite.Sprite):
    def __init__(self, enemy_type, level):
        pygame.sprite.Sprite.__init__(self)
        self.type = enemy_type
        self.level = level
        
        # Configuración según tipo
        if self.type == "basic":
            self.image = pygame.Surface((40, 30))
            self.image.fill(RED)
            self.rect = self.image.get_rect()
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-150, -100)
            self.speedy = random.randrange(1, 3) + level // 2
            self.speedx = random.randrange(-2, 3)
            self.health = 1
            self.score = 50
            self.shoot_delay = 2000 - level * 100
        elif self.type == "fast":
            self.image = pygame.Surface((30, 20))
            self.image.fill(BLUE)
            self.rect = self.image.get_rect()
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-150, -100)
            self.speedy = random.randrange(3, 6) + level // 2
            self.speedx = random.randrange(-3, 4)
            self.health = 1
            self.score = 100
            self.shoot_delay = 0  # no dispara
        elif self.type == "tank":
            self.image = pygame.Surface((50, 40))
            self.image.fill(ORANGE)
            self.rect = self.image.get_rect()
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-150, -100)
            self.speedy = random.randrange(1, 2) + level // 3
            self.speedx = random.randrange(-1, 2)
            self.health = 3 + level // 2
            self.score = 200
            self.shoot_delay = 2500 - level * 100
        
        self.last_shot = pygame.time.get_ticks()

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        
        # Cambiar dirección aleatoriamente
        if random.random() < 0.02:
            self.speedx = random.randrange(-3, 4)
            
        # Limitar movimiento horizontal
        if self.rect.right > WIDTH:
            self.speedx = -self.speedx
        if self.rect.left < 0:
            self.speedx = -self.speedx
            
        # Si sale de la pantalla, reposicionar arriba
        if self.rect.top > HEIGHT + 10:
            self.rect.x = random.randrange(WIDTH - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            
        # Disparar si el tipo lo permite
        now = pygame.time.get_ticks()
        if (self.type == "basic" or self.type == "tank") and now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            enemy_bullet = EnemyBullet(self.rect.centerx, self.rect.bottom)
            all_sprites.add(enemy_bullet)
            enemy_bullets.add(enemy_bullet)

    def hit(self):
        self.health -= 1
        if self.health <= 0:
            return True
        return False

# Clase Jefe
class Boss(pygame.sprite.Sprite):
    def __init__(self, level):
        pygame.sprite.Sprite.__init__(self)
        self.level = level
        self.image = pygame.Surface((120, 80))
        self.image.fill(PURPLE)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH / 2
        self.rect.y = 50
        self.speedx = 3 + level // 3
        self.health = 20 + level * 10
        self.max_health = self.health
        self.score = 1000 + level * 500
        self.shoot_delay = 800 - level * 30
        self.pattern = 0
        self.pattern_time = pygame.time.get_ticks()
        self.last_shot = pygame.time.get_ticks()
        self.enter_phase = True
        self.phase_end = pygame.time.get_ticks() + 2000

    def update(self):
        # Fase de entrada
        if self.enter_phase:
            if pygame.time.get_ticks() < self.phase_end:
                self.rect.y += 1
            else:
                self.enter_phase = False
            return
        
        # Cambiar patrones cada 5 segundos
        now = pygame.time.get_ticks()
        if now - self.pattern_time > 5000:
            self.pattern = (self.pattern + 1) % 3
            self.pattern_time = now
        
        # Patrón 0: movimiento horizontal
        if self.pattern == 0:
            self.rect.x += self.speedx
            if self.rect.right > WIDTH or self.rect.left < 0:
                self.speedx = -self.speedx
        # Patrón 1: movimiento diagonal
        elif self.pattern == 1:
            self.rect.x += self.speedx
            self.rect.y = 50 + 50 * math.sin((now % 3000) / 3000 * 2 * math.pi)
            if self.rect.right > WIDTH or self.rect.left < 0:
                self.speedx = -self.speedx
        # Patrón 2: quieto con más disparos
        elif self.pattern == 2:
            self.rect.centerx = WIDTH / 2
        
        # Disparar
        if now - self.last_shot > self.shoot_delay:
            self.last_shot = now
            if self.pattern == 2:  # Patrón de disparo multiple
                angles = [-30, -15, 0, 15, 30]
                for angle in angles:
                    enemy_bullet = EnemyBullet(self.rect.centerx, self.rect.bottom, angle)
                    all_sprites.add(enemy_bullet)
                    enemy_bullets.add(enemy_bullet)
            else:  # Disparo normal
                enemy_bullet1 = EnemyBullet(self.rect.left + 20, self.rect.bottom)
                enemy_bullet2 = EnemyBullet(self.rect.right - 20, self.rect.bottom)
                all_sprites.add(enemy_bullet1)
                all_sprites.add(enemy_bullet2)
                enemy_bullets.add(enemy_bullet1)
                enemy_bullets.add(enemy_bullet2)

    def hit(self):
        self.health -= 1
        if self.health <= 0:
            return True
        return False

# Clase Bala del Jugador
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((5, 10))
        self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y
        self.speedy = -10

    def update(self):
        self.rect.y += self.speedy
        # Eliminar si sale de la pantalla
        if self.rect.bottom < 0:
            self.kill()

# Clase Bala Enemiga
class EnemyBullet(pygame.sprite.Sprite):
    def __init__(self, x, y, angle=0):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((5, 10))
        self.image.fill(RED)
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.top = y
        self.speedy = 5
        
        # Para balas con ángulo
        if angle != 0:
            self.speedx = math.sin(math.radians(angle)) * 5
        else:
            self.speedx = 0

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        # Eliminar si sale de la pantalla
        if self.rect.top > HEIGHT:
            self.kill()

# Clase Explosión
class Explosion(pygame.sprite.Sprite):
    def __init__(self, center, size):
        pygame.sprite.Sprite.__init__(self)
        self.size = size
        self.image = pygame.Surface((size, size))
        self.image.fill(ORANGE)
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.frame = 0
        self.last_update = pygame.time.get_ticks()
        self.frame_rate = 50

    def update(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > self.frame_rate:
            self.last_update = now
            self.frame += 1
            if self.frame == 8:
                self.kill()
            else:
                center = self.rect.center
                self.image = pygame.Surface((self.size, self.size))
                self.image.fill((random.randint(200, 255), random.randint(0, 100), 0))
                self.rect = self.image.get_rect()
                self.rect.center = center

# Clase Power-Up
class PowerUp(pygame.sprite.Sprite):
    def __init__(self, center):
        pygame.sprite.Sprite.__init__(self)
        self.type = random.choice(['shield', 'gun'])
        self.image = pygame.Surface((20, 20))
        if self.type == 'shield':
            self.image.fill(BLUE)
        else:
            self.image.fill(YELLOW)
        self.rect = self.image.get_rect()
        self.rect.center = center
        self.speedy = 3

    def update(self):
        self.rect.y += self.speedy
        # Eliminar si sale de la pantalla
        if self.rect.top > HEIGHT:
            self.kill()

# Clase Estrella (fondo)
class Star:
    def __init__(self):
        self.x = random.randrange(0, WIDTH)
        self.y = random.randrange(0, HEIGHT)
        self.size = random.randrange(1, 3)
        self.speed = random.randrange(1, 3)

    def move(self):
        self.y += self.speed
        if self.y > HEIGHT:
            self.y = 0
            self.x = random.randrange(0, WIDTH)

    def draw(self):
        pygame.draw.circle(screen, WHITE, (self.x, self.y), self.size)

# Función para generar enemigos
def spawn_enemies(level):
    enemy_count = 5 + level * 3
    for i in range(enemy_count):
        enemy_type = random.choice(['basic', 'basic', 'fast', 'tank'])
        enemy = Enemy(enemy_type, level)
        all_sprites.add(enemy)
        enemies.add(enemy)

# Función para mostrar texto
def draw_text(surface, text, size, x, y, color=WHITE):
    font = pygame.font.SysFont('Arial', size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surface.blit(text_surface, text_rect)

# Función para mostrar barra de escudo
def draw_shield_bar(surface, x, y, percent):
    if percent < 0:
        percent = 0
    BAR_LENGTH = 100
    BAR_HEIGHT = 10
    fill = (percent / 100) * BAR_LENGTH
    outline_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surface, GREEN, fill_rect)
    pygame.draw.rect(surface, WHITE, outline_rect, 2)

# Función para mostrar barra de vida del jefe
def draw_boss_health(surface, x, y, percent):
    BAR_LENGTH = 400
    BAR_HEIGHT = 15
    fill = (percent / 100) * BAR_LENGTH
    outline_rect = pygame.Rect(x, y, BAR_LENGTH, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surface, RED, fill_rect)
    pygame.draw.rect(surface, WHITE, outline_rect, 2)

# Función para mostrar pantalla de inicio
def show_start_screen():
    screen.fill(BLACK)
    draw_text(screen, "DEFENSOR ESPACIAL", 64, WIDTH / 2, HEIGHT / 4, YELLOW)
    draw_text(screen, "10 Niveles de Acción Intensa", 30, WIDTH / 2, HEIGHT / 2 - 30)
    draw_text(screen, "Flechas para moverse, Espacio para disparar", 22, WIDTH / 2, HEIGHT / 2 + 30)
    draw_text(screen, "Presiona una tecla para comenzar", 18, WIDTH / 2, HEIGHT * 3 / 4)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYUP:
                waiting = False

# Función para mostrar pantalla de nivel completado
def show_level_complete_screen(level, score):
    screen.fill(BLACK)
    draw_text(screen, f"¡NIVEL {level} COMPLETADO!", 64, WIDTH / 2, HEIGHT / 4, GREEN)
    draw_text(screen, f"Puntuación: {score}", 30, WIDTH / 2, HEIGHT / 2)
    draw_text(screen, "Presiona una tecla para continuar", 18, WIDTH / 2, HEIGHT * 3 / 4)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYUP:
                waiting = False

# Función para mostrar pantalla de juego completado
def show_game_complete_screen(score):
    screen.fill(BLACK)
    draw_text(screen, "¡JUEGO COMPLETADO!", 64, WIDTH / 2, HEIGHT / 4, YELLOW)
    draw_text(screen, f"¡Has derrotado a todos los invasores!", 30, WIDTH / 2, HEIGHT / 2 - 30)
    draw_text(screen, f"Puntuación final: {score}", 30, WIDTH / 2, HEIGHT / 2 + 30)
    draw_text(screen, "Presiona una tecla para volver a jugar", 18, WIDTH / 2, HEIGHT * 3 / 4)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYUP:
                waiting = False

# Función para mostrar pantalla de game over
def show_game_over_screen(score):
    screen.fill(BLACK)
    draw_text(screen, "GAME OVER", 64, WIDTH / 2, HEIGHT / 4, RED)
    draw_text(screen, f"Puntuación final: {score}", 30, WIDTH / 2, HEIGHT / 2)
    draw_text(screen, "Presiona una tecla para jugar de nuevo", 18, WIDTH / 2, HEIGHT * 3 / 4)
    pygame.display.flip()
    waiting = True
    while waiting:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYUP:
                waiting = False

# Crear estrellas para el fondo
stars = []
for i in range(100):
    stars.append(Star())

# Bucle principal del juego
game_over = True
game_running = True
level = 1
score = 0

while game_running:
    if game_over:
        show_start_screen()
        game_over = False
        all_sprites = pygame.sprite.Group()
        enemies = pygame.sprite.Group()
        bosses = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        enemy_bullets = pygame.sprite.Group()
        powerups = pygame.sprite.Group()
        player = Player()
        all_sprites.add(player)
        level = 1
        score = 0
        spawn_enemies(level)
    
    # Actualizar
    clock.tick(FPS)
    
    # Eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_running = False
    
    # Actualizar todos los sprites
    all_sprites.update()
    
    # Comprobar colisiones entre balas del jugador y enemigos
    hits = pygame.sprite.groupcollide(enemies, bullets, False, True)
    for enemy, bullet_list in hits.items():
        if enemy.hit():
            score += enemy.score
            explosion = Explosion(enemy.rect.center, 30)
            all_sprites.add(explosion)
            enemy.kill()
            
            # Probabilidad de soltar powerup
            if random.random() > 0.9:
                powerup = PowerUp(enemy.rect.center)
                all_sprites.add(powerup)
                powerups.add(powerup)
    
    # Comprobar colisiones entre balas del jugador y jefes
    hits = pygame.sprite.groupcollide(bosses, bullets, False, True)
    for boss, bullet_list in hits.items():
        if boss.hit():
            score += boss.score
            for i in range(5):
                explosion = Explosion((
                    boss.rect.centerx + random.randrange(-40, 40),
                    boss.rect.centery + random.randrange(-40, 40)
                ), 40)
                all_sprites.add(explosion)
            boss.kill()
            
            # Terminar nivel si no quedan jefes ni enemigos
            if len(bosses) == 0 and len(enemies) == 0:
                if level < 10:
                    show_level_complete_screen(level, score)
                    level += 1
                    spawn_enemies(level)
                    if level % 2 == 0:  # Jefe cada 2 niveles
                        boss = Boss(level)
                        all_sprites.add(boss)
                        bosses.add(boss)
                else:
                    show_game_complete_screen(score)
                    game_over = True
        else:
            # Mostrar daño
            explosion = Explosion(
                (hits[boss][0].rect.centerx, hits[boss][0].rect.centery),
                20
            )
            all_sprites.add(explosion)
    
    # Comprobar si no quedan enemigos (y no hay jefe)
    if len(enemies) == 0 and len(bosses) == 0 and level <= 10:
        if level % 2 == 0:  # En niveles pares, pasar al siguiente nivel
            show_level_complete_screen(level, score)
            level += 1
            if level <= 10:
                spawn_enemies(level)
            else:
                show_game_complete_screen(score)
                game_over = True
        else:  # En niveles impares, crear jefe
            boss = Boss(level)
            all_sprites.add(boss)
            bosses.add(boss)
    
    # Comprobar colisiones entre jugador y enemigos
    hits = pygame.sprite.spritecollide(player, enemies, True)
    for hit in hits:
        player.shield -= 20
        explosion = Explosion(hit.rect.center, 30)
        all_sprites.add(explosion)
        enemy = Enemy(random.choice(['basic', 'basic', 'fast', 'tank']), level)
        all_sprites.add(enemy)
        enemies.add(enemy)
        if player.shield <= 0:
            explosion = Explosion(player.rect.center, 50)
            all_sprites.add(explosion)
            player.lives -= 1
            player.shield = 100
            player.hide()
            if player.lives == 0:
                show_game_over_screen(score)
                game_over = True
    
    # Comprobar colisiones entre jugador y balas enemigas
    hits = pygame.sprite.spritecollide(player, enemy_bullets, True)
    for hit in hits:
        player.shield -= 10
        explosion = Explosion(hit.rect.center, 15)
        all_sprites.add(explosion)
        if player.shield <= 0:
            explosion = Explosion(player.rect.center, 50)
            all_sprites.add(explosion)
            player.lives -= 1
            player.shield = 100
            player.hide()
            if player.lives == 0:
                show_game_over_screen(score)
                game_over = True
    
    # Comprobar colisiones entre jugador y powerups
    hits = pygame.sprite.spritecollide(player, powerups, True)
    for hit in hits:
        if hit.type == 'shield':
            player.shield += 20
            if player.shield > 100:
                player.shield = 100
        elif hit.type == 'gun':
            player.powerup()
    
    # Dibujar
    screen.fill(BLACK)
    
    # Dibujar estrellas de fondo
    for star in stars:
        star.move()
        star.draw()
    
    # Dibujar todos los sprites
    all_sprites.draw(screen)
    
    # Dibujar información
    draw_text(screen, f"Puntuación: {score}", 20, WIDTH / 2, 10)
    draw_text(screen, f"Nivel: {level}/10", 20, WIDTH - 100, 10)
    draw_shield_bar(screen, 5, 5, player.shield)
    draw_text(screen, f"Vidas: {player.lives}", 20, 55, 25)
    
    # Dibujar barra de vida del jefe si hay
    if len(bosses) > 0:
        boss = bosses.sprites()[0]
        health_percent = (boss.health / boss.max_health) * 100
        draw_boss_health(screen, WIDTH/2 - 200, 30, health_percent)
        draw_text(screen, "JEFE", 20, WIDTH/2, 30)
    
    # Actualizar pantalla
    pygame.display.flip()

pygame.quit()