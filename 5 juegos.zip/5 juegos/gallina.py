import pygame
import random
import sys

# Inicializar pygame
pygame.init()

# Configuración de la pantalla
ANCHO = 800
ALTO = 600
PANTALLA = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("La Gallina Que Cruza La Carretera")

# Colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
GRIS = (128, 128, 128)
VERDE = (0, 255, 0)
ROJO = (255, 0, 0)
AMARILLO = (255, 255, 0)
NARANJA = (255, 165, 0)

# Fuentes
fuente = pygame.font.Font(None, 36)

# Clase Gallina
class Gallina(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Crear superficie para la gallina
        self.image = pygame.Surface((40, 40), pygame.SRCALPHA)
        
        # Dibujar cuerpo (óvalo amarillo)
        pygame.draw.ellipse(self.image, AMARILLO, (0, 10, 40, 30))
        
        # Dibujar cabeza (círculo más pequeño)
        pygame.draw.circle(self.image, AMARILLO, (35, 15), 10)
        
        # Dibujar ojo
        pygame.draw.circle(self.image, NEGRO, (38, 12), 3)
        
        # Dibujar pico
        pygame.draw.polygon(self.image, NARANJA, [(40, 15), (47, 18), (40, 21)])
        
        # Dibujar patas
        pygame.draw.line(self.image, NARANJA, (10, 40), (5, 45), 3)
        pygame.draw.line(self.image, NARANJA, (25, 40), (30, 45), 3)
        
        # Crear rectángulo de colisión
        self.rect = self.image.get_rect()
        self.rect.centerx = ANCHO // 2
        self.rect.bottom = ALTO - 10
        self.velocidad = 5
    
    def update(self, teclas):
        if teclas[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.velocidad
        if teclas[pygame.K_RIGHT] and self.rect.right < ANCHO:
            self.rect.x += self.velocidad
        if teclas[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.velocidad
        if teclas[pygame.K_DOWN] and self.rect.bottom < ALTO:
            self.rect.y += self.velocidad

# Clase Carro
class Carro(pygame.sprite.Sprite):
    def __init__(self, velocidad, carril):
        super().__init__()
        self.image = pygame.Surface((80, 40))
        self.image.fill((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
        
        # Dibujar faros y detalles del coche
        pygame.draw.rect(self.image, AMARILLO, (0 if velocidad > 0 else 70, 5, 10, 10))
        pygame.draw.rect(self.image, AMARILLO, (0 if velocidad > 0 else 70, 25, 10, 10))
        pygame.draw.rect(self.image, (200, 0, 0), (70 if velocidad > 0 else 0, 5, 10, 30))
        
        self.rect = self.image.get_rect()
        
        # Posición inicial (izquierda o derecha de la pantalla)
        self.direccion = random.choice([-1, 1])
        if self.direccion == 1:
            self.rect.right = 0
        else:
            self.rect.left = ANCHO
            
        self.rect.y = 100 + carril * 60
        self.velocidad = velocidad * self.direccion
    
    def update(self):
        self.rect.x += self.velocidad
        
        # Si el carro sale de la pantalla, eliminarlo
        if (self.direccion == 1 and self.rect.left > ANCHO) or (self.direccion == -1 and self.rect.right < 0):
            self.kill()

# Clase Juego
class Juego:
    def __init__(self):
        self.gallina = Gallina()
        self.todos_sprites = pygame.sprite.Group()
        self.carros = pygame.sprite.Group()
        self.todos_sprites.add(self.gallina)
        
        self.nivel = 1
        self.puntos = 0
        self.vidas = 3
        self.jugando = True
        
        self.meta = pygame.Rect(0, 50, ANCHO, 10)
        self.tiempo_transcurrido = 0
        self.tiempo_creacion_carro = 0
        self.frecuencia_carros = 2000  # milisegundos
        
    def procesar_eventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                return False
        return True
    
    def crear_carros(self, dt):
        self.tiempo_creacion_carro += dt
        if self.tiempo_creacion_carro > self.frecuencia_carros / self.nivel:
            self.tiempo_creacion_carro = 0
            velocidad_base = 2 + self.nivel * 0.5
            for i in range(min(3, self.nivel)):
                carril = random.randint(0, 4)
                velocidad = velocidad_base + random.random() * 2
                carro = Carro(velocidad, carril)
                self.carros.add(carro)
                self.todos_sprites.add(carro)
    
    def actualizar(self, dt):
        if not self.jugando:
            return True
        
        # Crear nuevos carros
        self.crear_carros(dt)
        
        # Actualizar posiciones
        teclas = pygame.key.get_pressed()
        self.gallina.update(teclas)
        self.carros.update()
        
        # Comprobar colisiones
        if pygame.sprite.spritecollide(self.gallina, self.carros, False):
            self.vidas -= 1
            self.reiniciar_gallina()
            if self.vidas <= 0:
                self.jugando = False
        
        # Comprobar si la gallina llegó a la meta
        if self.gallina.rect.top <= self.meta.bottom:
            self.nivel += 1
            self.puntos += self.nivel * 100
            self.reiniciar_gallina()
            self.frecuencia_carros = max(300, 2000 - self.nivel * 100)
        
        return True
    
    def reiniciar_gallina(self):
        self.gallina.rect.centerx = ANCHO // 2
        self.gallina.rect.bottom = ALTO - 10
    
    def dibujar(self):
        PANTALLA.fill(VERDE)  # Fondo verde como césped
        
        # Dibujar carretera
        for i in range(5):
            pygame.draw.rect(PANTALLA, NEGRO, (0, 100 + i * 60, ANCHO, 50))
            for j in range(10):
                pygame.draw.rect(PANTALLA, BLANCO, (j * 80 + 10, 100 + i * 60 + 25, 60, 5))
        
        # Dibujar meta
        pygame.draw.rect(PANTALLA, VERDE, self.meta)
        texto_meta = fuente.render("META", True, BLANCO)
        PANTALLA.blit(texto_meta, (ANCHO // 2 - texto_meta.get_width() // 2, 15))
        
        # Dibujar sprites
        self.todos_sprites.draw(PANTALLA)
        
        # Mostrar información
        texto_nivel = fuente.render(f"Nivel: {self.nivel}", True, NEGRO)
        texto_puntos = fuente.render(f"Puntos: {self.puntos}", True, NEGRO)
        texto_vidas = fuente.render(f"Vidas: {self.vidas}", True, NEGRO)
        PANTALLA.blit(texto_nivel, (10, 10))
        PANTALLA.blit(texto_puntos, (150, 10))
        PANTALLA.blit(texto_vidas, (300, 10))
        
        # Mostrar fin del juego
        if not self.jugando:
            # Fondo semitransparente
            superficie = pygame.Surface((ANCHO, 100))
            superficie.set_alpha(200)
            superficie.fill(NEGRO)
            PANTALLA.blit(superficie, (0, ALTO // 2 - 50))
            
            texto_fin = fuente.render("FIN DEL JUEGO - Presiona ESC para salir", True, BLANCO)
            PANTALLA.blit(texto_fin, (ANCHO // 2 - texto_fin.get_width() // 2, ALTO // 2))
        
        pygame.display.flip()

# Función principal
def main():
    juego = Juego()
    reloj = pygame.time.Clock()
    ejecutando = True
    
    while ejecutando:
        dt = reloj.tick(60)
        
        # Manejar eventos
        ejecutando = juego.procesar_eventos()
        
        # Actualizar juego
        juego.actualizar(dt)
        
        # Dibujar pantalla
        juego.dibujar()
        
        # Salir con ESC si el juego terminó
        teclas = pygame.key.get_pressed()
        if not juego.jugando and teclas[pygame.K_ESCAPE]:
            ejecutando = False
    
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()