import pygame
import random
import sys

# Inicializar pygame
pygame.init()

# Constantes
ANCHO = 800
ALTO = 600
FPS = 60
GRAVEDAD = 1
SALTO = -18
VELOCIDAD_JUGADOR = 5
VELOCIDAD_BARRIL = 3

# Colores
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
ROJO = (255, 0, 0)
AZUL = (0, 0, 255)
VERDE = (0, 255, 0)
MARRON = (139, 69, 19)

# Configuración de la pantalla
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Donkey Kong Python")
reloj = pygame.time.Clock()

# Clase Jugador
class Jugador(pygame.sprite.Sprite):
    def __init__(self, plataformas):
        super().__init__()
        self.image = pygame.Surface((30, 50))
        self.image.fill(AZUL)
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = ALTO - 150
        self.velocidad_y = 0
        self.plataformas = plataformas
        self.en_suelo = False
        self.puntos = 0

    def update(self):
        # Gravedad
        self.velocidad_y += GRAVEDAD
        self.rect.y += self.velocidad_y

        # Comprobar colisión con plataformas
        self.en_suelo = False
        for plataforma in self.plataformas:
            if self.rect.bottom > plataforma.rect.top and self.rect.bottom <= plataforma.rect.top + 20 and self.velocidad_y > 0:
                if self.rect.right > plataforma.rect.left and self.rect.left < plataforma.rect.right:
                    self.rect.bottom = plataforma.rect.top
                    self.velocidad_y = 0
                    self.en_suelo = True

        # Límites de pantalla
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > ANCHO:
            self.rect.right = ANCHO
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > ALTO:
            self.rect.bottom = ALTO
            self.velocidad_y = 0
            self.en_suelo = True

    def saltar(self):
        if self.en_suelo:
            self.velocidad_y = SALTO

    def mover_izquierda(self):
        self.rect.x -= VELOCIDAD_JUGADOR

    def mover_derecha(self):
        self.rect.x += VELOCIDAD_JUGADOR

# Clase Plataforma
class Plataforma(pygame.sprite.Sprite):
    def __init__(self, x, y, ancho, alto):
        super().__init__()
        self.image = pygame.Surface((ancho, alto))
        self.image.fill(MARRON)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

# Clase Barril
class Barril(pygame.sprite.Sprite):
    def __init__(self, plataformas):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill(ROJO)
        pygame.draw.circle(self.image, ROJO, (15, 15), 15)
        self.rect = self.image.get_rect()
        self.rect.x = 150
        self.rect.y = 100
        self.velocidad_x = random.choice([-1, 1]) * VELOCIDAD_BARRIL
        self.velocidad_y = 0
        self.plataformas = plataformas
        self.en_plataforma = False
        self.ultima_plataforma = None
        self.tiempo_caida = 0

    def update(self):
        # Gravedad
        self.velocidad_y += GRAVEDAD * 0.8
        
        # Actualizar posición vertical
        self.rect.y += self.velocidad_y
        
        # Comprobar si está en una plataforma
        self.en_plataforma = False
        for plataforma in self.plataformas:
            if self.rect.bottom > plataforma.rect.top and self.rect.bottom <= plataforma.rect.top + 20 and self.velocidad_y > 0:
                if self.rect.right > plataforma.rect.left and self.rect.left < plataforma.rect.right:
                    # Detectar si está en el borde de la plataforma
                    if (self.velocidad_x > 0 and self.rect.right >= plataforma.rect.right - 10) or \
                       (self.velocidad_x < 0 and self.rect.left <= plataforma.rect.left + 10):
                        # Probabilidad de caer de la plataforma
                        if random.random() < 0.8 and self.ultima_plataforma != plataforma:
                            # Permitir caer al siguiente nivel
                            self.tiempo_caida = 1
                            break
                    
                    # Si no cae, se queda en la plataforma
                    self.rect.bottom = plataforma.rect.top
                    self.velocidad_y = 0
                    self.en_plataforma = True
                    self.ultima_plataforma = plataforma
        
        # Si el barril está en tiempo de caída, no actualizar posición horizontal
        if self.tiempo_caida > 0:
            self.tiempo_caida -= 1
        else:
            # Actualizar posición horizontal
            self.rect.x += self.velocidad_x
            
            # Rebotar en los bordes de la pantalla
            if self.rect.left < 0:
                self.velocidad_x = abs(self.velocidad_x)
            if self.rect.right > ANCHO:
                self.velocidad_x = -abs(self.velocidad_x)
        
        # Eliminar si sale de la pantalla por abajo
        if self.rect.top > ALTO:
            self.kill()

# Clase Princesa
class Princesa(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((40, 60))
        self.image.fill(VERDE)
        self.rect = self.image.get_rect()
        self.rect.x = ANCHO - 100
        self.rect.y = 50

# Clase Gorila
class Gorila(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((60, 80))
        self.image.fill((139, 69, 19))  # Marrón
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = 50
        self.tiempo_barril = 0

    def update(self):
        self.tiempo_barril += 1

    def debe_lanzar_barril(self):
        if self.tiempo_barril > 60:
            self.tiempo_barril = 0
            return True
        return False

# Crear grupos de sprites
todos_sprites = pygame.sprite.Group()
barriles = pygame.sprite.Group()
plataformas = pygame.sprite.Group()

# Crear plataformas en zigzag (más parecido al Donkey Kong original)
plat_ancho = ANCHO - 100
plat_direccion = 1  # 1 para plataformas que comienzan en la izquierda, -1 para las que comienzan en la derecha

for i in range(5):
    # Si la dirección es 1, la plataforma comienza en la izquierda
    # Si la dirección es -1, la plataforma comienza en la derecha
    if plat_direccion == 1:
        plat_x = 0
    else:
        plat_x = ANCHO - plat_ancho
        
    plat = Plataforma(plat_x, ALTO - 100 - i * 100, plat_ancho, 20)
    todos_sprites.add(plat)
    plataformas.add(plat)
    
    # Alternar la dirección para la siguiente plataforma
    plat_direccion *= -1

# Crear jugador, princesa y gorila
jugador = Jugador(plataformas)
princesa = Princesa()
gorila = Gorila()

todos_sprites.add(jugador)
todos_sprites.add(princesa)
todos_sprites.add(gorila)

# Bucle principal de juego
ejecutando = True
game_over = False
victoria = False
font = pygame.font.SysFont(None, 48)

while ejecutando:
    reloj.tick(FPS)

    # Procesar eventos
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False
        elif evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_SPACE and not game_over and not victoria:
                jugador.saltar()
            elif evento.key == pygame.K_r and (game_over or victoria):
                # Reiniciar juego
                game_over = False
                victoria = False
                jugador.rect.x = 100
                jugador.rect.y = ALTO - 150
                jugador.velocidad_y = 0
                jugador.puntos = 0
                for barril in barriles:
                    barril.kill()

    if not game_over and not victoria:
        # Movimiento del jugador
        teclas = pygame.key.get_pressed()
        if teclas[pygame.K_LEFT]:
            jugador.mover_izquierda()
        if teclas[pygame.K_RIGHT]:
            jugador.mover_derecha()

        # Lanzar barriles
        if gorila.debe_lanzar_barril():
            nuevo_barril = Barril(plataformas)
            todos_sprites.add(nuevo_barril)
            barriles.add(nuevo_barril)

        # Actualizar
        todos_sprites.update()

        # Comprobar colisiones con barriles
        colisiones = pygame.sprite.spritecollide(jugador, barriles, True)
        if colisiones:
            game_over = True

        # Comprobar victoria
        if pygame.sprite.collide_rect(jugador, princesa):
            victoria = True
            jugador.puntos += 100

    # Dibujar
    pantalla.fill(NEGRO)
    todos_sprites.draw(pantalla)

    # Mostrar puntuación
    texto_puntos = font.render(f"Puntos: {jugador.puntos}", True, BLANCO)
    pantalla.blit(texto_puntos, (10, 10))

    # Mostrar mensajes de fin de juego
    if game_over:
        texto_game_over = font.render("¡GAME OVER! Presiona R para reiniciar", True, ROJO)
        pantalla.blit(texto_game_over, (ANCHO // 2 - 240, ALTO // 2))
    
    if victoria:
        texto_victoria = font.render("¡VICTORIA! Presiona R para reiniciar", True, VERDE)
        pantalla.blit(texto_victoria, (ANCHO // 2 - 220, ALTO // 2))

    pygame.display.flip()

pygame.quit()
sys.exit()