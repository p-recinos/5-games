# Cabeza
        pygame.draw.circle(superficie, (255, 220, 100), (int(pollo_x + 15), int(pollo_y - 5)), 15)
        
        # Cresta
        pygame.draw.polygon(superficie, (255, 50, 50), 
                          [(pollo_x + 15, pollo_y - 20), 
                           (pollo_x + 20, pollo_y - 30), 
                           (pollo_x + 25, pollo_y - 20),
                           (pollo_x + 30, pollo_y - 28),
                           (pollo_x + 35, pollo_y - 18)])
        
        # Pico
        pygame.draw.polygon(superficie, (255, 150, 0), 
                          [(pollo_x + 30, pollo_y - 5), 
                           (pollo_x + 40, pollo_y),
                           (pollo_x + 30, pollo_y + 5)])
        
        # Ojos
        pygame.draw.circle(superficie, (0, 0, 0), (int(pollo_x + 25), int(pollo_y - 8)), 3)
        
        # Patas
        pygame.draw.rect(superficie, (255, 150, 0), (pollo_x - 10, pollo_y + 15, 5, 15))
        pygame.draw.rect(superficie, (255, 150, 0), (pollo_x + 5, pollo_y + 15, 5, 15))
        
        # Árbol
        arbol_x = ancho * 0.15
        arbol_y = alto * 0.6
        pygame.draw.rect(superficie, (100, 70, 30), (arbol_x - 5, arbol_y, 10, alto * 0.2))
        pygame.draw.circle(superficie, (30, 120, 30), (int(arbol_x), int(arbol_y)), int(alto * 0.1))
    
    def iniciar_juego(self):
        # Crear imagen del rompecabezas
        self.imagen_completa = self.crear_imagen_ejemplo()
        
        # Determinar el tamaño de cada pieza
        ancho_pieza = self.imagen_completa.get_width() // self.grid_size[0]
        alto_pieza = self.imagen_completa.get_height() // self.grid_size[1]
        
        # Crear piezas del rompecabezas
        self.piezas = []
        for fila in range(self.grid_size[1]):
            for col in range(self.grid_size[0]):
                # Recortar la porción de la imagen
                pieza_surf = pygame.Surface((ancho_pieza, alto_pieza))
                pieza_surf.blit(self.imagen_completa, (0, 0), 
                             (col * ancho_pieza, fila * alto_pieza, ancho_pieza, alto_pieza))
                
                # Posición original (correcta)
                pos_original = (col, fila)
                
                # Posición actual (aleatoria)
                pos_actual = (random.randint(0, self.grid_size[0]-1), 
                            random.randint(0, self.grid_size[1]-1))
                
                # Rotación aleatoria si está habilitado el modo rotación
                rotacion = 0
                if self.modo_rotacion:
                    rotacion = random.choice([0, 90, 180, 270])
                
                # Crear la pieza
                pieza = PiezaRompecabezas(len(self.piezas), pieza_surf, pos_original, pos_actual, rotacion)
                self.piezas.append(pieza)
        
        # Configurar tiempo
        self.tiempo_inicio = pygame.time.get_ticks()
        self.tiempo_completado = 0
        
        # Establecer límite de tiempo si está activado
        if self.modo_tiempo:
            # El límite de tiempo depende del nivel (más tiempo para niveles más difíciles)
            self.tiempo_limite = 60 + self.nivel * 30  # segundos
        else:
            self.tiempo_limite = 0
        
        # Reiniciar estado del juego
        self.comenzar = True
        self.completado = False
        self.pieza_seleccionada = None
    
    def dibujar_botones(self, superficie):
        for boton in self.botones:
            # Dibujar fondo del botón
            color = GRIS_CLARO
            if 'hover' in boton and boton['hover']:
                color = (220, 220, 220)
            pygame.draw.rect(superficie, color, boton['rect'])
            pygame.draw.rect(superficie, NEGRO, boton['rect'], 2)
            
            # Dibujar texto del botón
            texto = fuente_pequeña.render(boton['texto'], True, NEGRO)
            texto_rect = texto.get_rect(center=boton['rect'].center)
            superficie.blit(texto, texto_rect)
    
    def verificar_rompecabezas_completado(self):
        for pieza in self.piezas:
            if pieza.pos_actual != pieza.pos_original or pieza.rotacion != 0:
                return False
        return True
    
    def intercambiar_piezas(self, pieza1, pieza2):
        # Guardar posición temporal
        temp_pos = pieza1.pos_actual
        
        # Intercambiar posiciones
        pieza1.actualizar_posicion(pieza2.pos_actual)
        pieza2.actualizar_posicion(temp_pos)
        
        # Verificar si se ha completado el rompecabezas
        if self.verificar_rompecabezas_completado():
            self.completado = True
            self.tiempo_completado = (pygame.time.get_ticks() - self.tiempo_inicio) // 1000
            self.puntaje += 100 * self.nivel
            self.sonido_exito.play()
            self.tiempo_espera_nivel = pygame.time.get_ticks()
    
    def manejar_eventos(self, evento):
        if evento.type == MOUSEBUTTONDOWN:
            # Verificar si se hizo clic en un botón
            for boton in self.botones:
                if boton['rect'].collidepoint(evento.pos):
                    boton['accion']()
                    return
            
            if not self.comenzar or self.completado:
                return
            
            # Verificar si se hizo clic en una pieza
            for pieza in self.piezas:
                if pieza.rect.collidepoint(evento.pos):
                    # Botón izquierdo: seleccionar/intercambiar
                    if evento.button == 1:
                        if self.pieza_seleccionada is None:
                            # Seleccionar pieza
                            pieza.seleccionada = True
                            self.pieza_seleccionada = pieza
                        else:
                            # Si la pieza ya estaba seleccionada, deseleccionarla
                            if self.pieza_seleccionada == pieza:
                                pieza.seleccionada = False
                                self.pieza_seleccionada = None
                            else:
                                # Intercambiar con la pieza seleccionada anteriormente
                                self.pieza_seleccionada.seleccionada = False
                                self.intercambiar_piezas(self.pieza_seleccionada, pieza)
                                self.pieza_seleccionada = None
                    # Botón derecho: rotar (si está habilitado)
                    elif evento.button == 3 and self.modo_rotacion:
                        pieza.rotar_90()
                        # Verificar si se ha completado el rompecabezas tras la rotación
                        if self.verificar_rompecabezas_completado():
                            self.completado = True
                            self.tiempo_completado = (pygame.time.get_ticks() - self.tiempo_inicio) // 1000
                            self.puntaje += 100 * self.nivel
                            self.sonido_exito.play()
                            self.tiempo_espera_nivel = pygame.time.get_ticks()
                    return
        
        elif evento.type == MOUSEMOTION:
            # Verificar si el ratón está sobre algún botón
            for boton in self.botones:
                boton['hover'] = boton['rect'].collidepoint(evento.pos)
    
    def actualizar(self):
        # Si el juego está completado y ha pasado tiempo suficiente, avanzar al siguiente nivel
        if self.completado and self.tiempo_espera_nivel > 0:
            tiempo_actual = pygame.time.get_ticks()
            if tiempo_actual - self.tiempo_espera_nivel >= 3000:  # 3 segundos
                self.tiempo_espera_nivel = 0
                self.avanzar_nivel()
        
        # Verificar si se ha agotado el tiempo (en modo tiempo)
        if self.comenzar and not self.completado and self.modo_tiempo and self.tiempo_limite > 0:
            tiempo_actual = (pygame.time.get_ticks() - self.tiempo_inicio) // 1000
            if tiempo_actual >= self.tiempo_limite:
                self.vidas -= 1
                self.sonido_error.play()
                if self.vidas <= 0:
                    # Game over
                    self.comenzar = False
                else:
                    # Reiniciar nivel
                    self.iniciar_juego()
    
    def dibujar(self, superficie):
        superficie.fill(BLANCO)
        
        # Dibujar botones
        self.dibujar_botones(superficie)
        
        # Mostrar información del juego
        texto_puntaje = fuente.render(f"Puntaje: {self.puntaje}", True, NEGRO)
        superficie.blit(texto_puntaje, (50, ALTO - 50))
        
        texto_vidas = fuente.render(f"Vidas: {self.vidas}", True, NEGRO)
        superficie.blit(texto_vidas, (250, ALTO - 50))
        
        # Mostrar tiempo
        if self.comenzar and not self.completado:
            tiempo_actual = (pygame.time.get_ticks() - self.tiempo_inicio) // 1000
            color_tiempo = NEGRO
            
            # En modo tiempo, mostrar cuenta regresiva
            if self.modo_tiempo and self.tiempo_limite > 0:
                tiempo_restante = max(0, self.tiempo_limite - tiempo_actual)
                texto_tiempo = fuente.render(f"Tiempo: {tiempo_restante}s", True, color_tiempo)
                
                # Cambiar a rojo si queda poco tiempo
                if tiempo_restante < 10:
                    color_tiempo = ROJO
                    texto_tiempo = fuente.render(f"Tiempo: {tiempo_restante}s", True, color_tiempo)
            else:
                texto_tiempo = fuente.render(f"Tiempo: {tiempo_actual}s", True, color_tiempo)
            
            superficie.blit(texto_tiempo, (450, ALTO - 50))
        
        elif self.completado:
            texto_completado = fuente_grande.render("¡Rompecabezas Completado!", True, VERDE)
            superficie.blit(texto_completado, (ANCHO // 2 - texto_completado.get_width() // 2, ALTO - 100))
            
            texto_tiempo = fuente.render(f"Tiempo: {self.tiempo_completado}s", True, NEGRO)
            superficie.blit(texto_tiempo, (450, ALTO - 50))
        
        # Si el juego no ha comenzado, mostrar un mensaje
        if not self.comenzar and not self.completado:
            if self.vidas <= 0:
                texto_inicio = fuente_grande.render("Game Over - Presiona Comenzar", True, ROJO)
            else:
                texto_inicio = fuente_grande.render("Presiona Comenzar para jugar", True, AZUL)
            superficie.blit(texto_inicio, (ANCHO // 2 - texto_inicio.get_width() // 2, ALTO // 2))
            return
        
        # Dibujar piezas del rompecabezas
        for pieza in self.piezas:
            pieza.dibujar(superficie)

# Función principal
def main():
    juego = JuegoRompecabezas()
    reloj = pygame.time.Clock()
    
    while True:
        for evento in pygame.event.get():
            if evento.type == QUIT:
                pygame.quit()
                sys.exit()
            
            juego.manejar_eventos(evento)
        
        juego.actualizar()
        juego.dibujar(PANTALLA)
        
        pygame.display.flip()
        reloj.tick(60)

if __name__ == "__main__":
    main()