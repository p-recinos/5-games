import random
import tkinter as tk
from tkinter import messagebox, font

# Base de datos de preguntas (usando las mismas preguntas del código original)
preguntas = [
    {
        "pregunta": "¿Cuál es el río más largo del mundo?",
        "opciones": ["a) Nilo", "b) Amazonas", "c) Misisipi"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿En qué año comenzó la Primera Guerra Mundial?",
        "opciones": ["a) 1914", "b) 1916", "c) 1918"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es el elemento químico más abundante en la Tierra?",
        "opciones": ["a) Oxígeno", "b) Hierro", "c) Silicio"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Quién pintó 'La noche estrellada'?",
        "opciones": ["a) Pablo Picasso", "b) Claude Monet", "c) Vincent van Gogh"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es la capital de Australia?",
        "opciones": ["a) Sydney", "b) Melbourne", "c) Canberra"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿En qué año llegó el hombre a la Luna?",
        "opciones": ["a) 1965", "b) 1969", "c) 1972"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién escribió 'Cien años de soledad'?",
        "opciones": ["a) Gabriel García Márquez", "b) Julio Cortázar", "c) Mario Vargas Llosa"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es el planeta más grande del Sistema Solar?",
        "opciones": ["a) Saturno", "b) Júpiter", "c) Neptuno"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es el océano más grande del mundo?",
        "opciones": ["a) Océano Atlántico", "b) Océano Índico", "c) Océano Pacífico"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el hueso más largo del cuerpo humano?",
        "opciones": ["a) Fémur", "b) Húmero", "c) Tibia"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Quién fue el primer presidente de Estados Unidos?",
        "opciones": ["a) Thomas Jefferson", "b) George Washington", "c) Abraham Lincoln"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿En qué año cayó el Muro de Berlín?",
        "opciones": ["a) 1987", "b) 1989", "c) 1991"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es la montaña más alta del mundo?",
        "opciones": ["a) K2", "b) Monte Everest", "c) Aconcagua"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién desarrolló la teoría de la relatividad?",
        "opciones": ["a) Isaac Newton", "b) Albert Einstein", "c) Stephen Hawking"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es el país más poblado del mundo?",
        "opciones": ["a) India", "b) Estados Unidos", "c) China"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el idioma más hablado del mundo?",
        "opciones": ["a) Inglés", "b) Español", "c) Mandarín"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el símbolo químico del oro?",
        "opciones": ["a) Au", "b) Ag", "c) Fe"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿En qué continente se encuentra Egipto?",
        "opciones": ["a) África", "b) Asia", "c) Europa"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es la capital de Canadá?",
        "opciones": ["a) Toronto", "b) Montreal", "c) Ottawa"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Quién escribió 'Don Quijote de la Mancha'?",
        "opciones": ["a) Federico García Lorca", "b) Miguel de Cervantes", "c) Lope de Vega"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿En qué año se descubrió América?",
        "opciones": ["a) 1492", "b) 1498", "c) 1500"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es el animal terrestre más rápido?",
        "opciones": ["a) León", "b) Guepardo", "c) Gacela"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién pintó la Mona Lisa?",
        "opciones": ["a) Rafael", "b) Miguel Ángel", "c) Leonardo da Vinci"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es la capital de Japón?",
        "opciones": ["a) Shanghái", "b) Pekín", "c) Tokio"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿En qué año terminó la Segunda Guerra Mundial?",
        "opciones": ["a) 1943", "b) 1945", "c) 1947"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es el metal más abundante en la corteza terrestre?",
        "opciones": ["a) Hierro", "b) Aluminio", "c) Cobre"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién compuso la 'Novena Sinfonía'?",
        "opciones": ["a) Wolfgang Amadeus Mozart", "b) Ludwig van Beethoven", "c) Johann Sebastian Bach"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es la única capital europea atravesada por un río que desemboca en el océano Atlántico?",
        "opciones": ["a) Londres", "b) París", "c) Lisboa"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el órgano más grande del cuerpo humano?",
        "opciones": ["a) Hígado", "b) Pulmones", "c) Piel"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Quién fue el autor de 'La Odisea'?",
        "opciones": ["a) Sófocles", "b) Homero", "c) Aristóteles"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es el país con mayor extensión territorial?",
        "opciones": ["a) China", "b) Estados Unidos", "c) Rusia"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿En qué año se fundó la ONU?",
        "opciones": ["a) 1945", "b) 1950", "c) 1955"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es el principal gas de la atmósfera terrestre?",
        "opciones": ["a) Oxígeno", "b) Dióxido de carbono", "c) Nitrógeno"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Quién formuló la teoría de la evolución por selección natural?",
        "opciones": ["a) Gregor Mendel", "b) Charles Darwin", "c) Louis Pasteur"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿En qué país se encuentra la Torre Eiffel?",
        "opciones": ["a) Italia", "b) Inglaterra", "c) Francia"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el instrumento musical de viento más grande?",
        "opciones": ["a) Tuba", "b) Trombón", "c) Contrafagot"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Quién fue el primer ser humano en viajar al espacio?",
        "opciones": ["a) Neil Armstrong", "b) Yuri Gagarin", "c) Alan Shepard"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es la capital de Rusia?",
        "opciones": ["a) Kiev", "b) San Petersburgo", "c) Moscú"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el lago más profundo del mundo?",
        "opciones": ["a) Lago Superior", "b) Lago Baikal", "c) Lago Victoria"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién fue el autor de 'Romeo y Julieta'?",
        "opciones": ["a) William Shakespeare", "b) Oscar Wilde", "c) Jane Austen"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿En qué año comenzó la Revolución Francesa?",
        "opciones": ["a) 1789", "b) 1798", "c) 1804"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es el planeta más cercano al Sol?",
        "opciones": ["a) Venus", "b) Mercurio", "c) Marte"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién inventó la bombilla eléctrica?",
        "opciones": ["a) Nikola Tesla", "b) Thomas Edison", "c) Alexander Graham Bell"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es la capital de Brasil?",
        "opciones": ["a) São Paulo", "b) Río de Janeiro", "c) Brasilia"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿Cuál es el segundo planeta del Sistema Solar?",
        "opciones": ["a) Venus", "b) Tierra", "c) Marte"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Quién ganó el Mundial de Fútbol de 2018?",
        "opciones": ["a) Brasil", "b) Alemania", "c) Francia"],
        "respuesta_correcta": "c"
    },
    {
        "pregunta": "¿En qué año se independizó México de España?",
        "opciones": ["a) 1810", "b) 1821", "c) 1836"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Cuál es el símbolo químico del sodio?",
        "opciones": ["a) So", "b) Na", "c) Sd"],
        "respuesta_correcta": "b"
    },
    {
        "pregunta": "¿Quién pintó 'La última cena'?",
        "opciones": ["a) Leonardo da Vinci", "b) Miguel Ángel", "c) Rafael"],
        "respuesta_correcta": "a"
    },
    {
        "pregunta": "¿Cuál es la capital de Sudáfrica?",
        "opciones": ["a) Johannesburgo", "b) Ciudad del Cabo", "c) Pretoria"],
        "respuesta_correcta": "c"
    }
]

class JuegoTrivia:
    def __init__(self, root):
        self.root = root
        self.root.title("Juego de Trivia - Cultura General")
        self.root.geometry("800x600")
        self.root.resizable(False, False)
        self.root.configure(bg="#282c34")
        
        # Definir fuentes
        self.titulo_font = font.Font(family="Helvetica", size=18, weight="bold")
        self.pregunta_font = font.Font(family="Helvetica", size=14, weight="bold")
        self.opcion_font = font.Font(family="Helvetica", size=12)
        self.boton_font = font.Font(family="Helvetica", size=12, weight="bold")
        
        # Variables del juego
        self.preguntas_juego = []
        self.pregunta_actual = 0
        self.puntuacion = 0
        self.total_preguntas = 10
        self.respuesta_seleccionada = tk.StringVar()
        self.juego_iniciado = False
        
        self.crear_pantalla_inicio()
    
    def crear_pantalla_inicio(self):
        # Marco principal
        self.marco_inicio = tk.Frame(self.root, bg="#282c34", padx=20, pady=20)
        self.marco_inicio.pack(fill="both", expand=True)
        
        # Título del juego
        tk.Label(
            self.marco_inicio, 
            text="JUEGO DE PREGUNTAS\nDE CULTURA GENERAL", 
            font=self.titulo_font, 
            bg="#282c34", 
            fg="#61dafb",
            pady=30
        ).pack()
        
        # Imagen o logo (podría añadirse aquí)
        
        # Botón para iniciar el juego
        tk.Button(
            self.marco_inicio,
            text="¡INICIAR JUEGO!",
            font=self.boton_font,
            bg="#61dafb",
            fg="#282c34",
            padx=20,
            pady=10,
            relief=tk.RAISED,
            command=self.iniciar_juego
        ).pack(pady=30)
        
        # Información del juego
        tk.Label(
            self.marco_inicio,
            text="Responde correctamente a 10 preguntas de cultura general",
            font=self.opcion_font,
            bg="#282c34",
            fg="white",
            pady=10
        ).pack()
        
        # Créditos
        tk.Label(
            self.marco_inicio,
            text="© 2025 - Juego de Trivia en Python",
            font=font.Font(family="Helvetica", size=8),
            bg="#282c34",
            fg="#666666",
            pady=20
        ).pack(side=tk.BOTTOM)
    
    def iniciar_juego(self):
        # Seleccionar preguntas aleatorias
        self.preguntas_juego = random.sample(preguntas, self.total_preguntas)
        self.pregunta_actual = 0
        self.puntuacion = 0
        self.juego_iniciado = True
        
        # Limpiar pantalla de inicio
        self.marco_inicio.destroy()
        
        # Crear pantalla de juego
        self.crear_pantalla_juego()
        
        # Mostrar la primera pregunta
        self.mostrar_pregunta()
    
    def crear_pantalla_juego(self):
        # Marco principal de juego
        self.marco_juego = tk.Frame(self.root, bg="#282c34", padx=20, pady=20)
        self.marco_juego.pack(fill="both", expand=True)
        
        # Marco para la cabecera (puntuación y número de pregunta)
        self.marco_cabecera = tk.Frame(self.marco_juego, bg="#21252b", padx=10, pady=10)
        self.marco_cabecera.pack(fill="x", pady=(0, 20))
        
        # Etiqueta para número de pregunta
        self.lbl_num_pregunta = tk.Label(
            self.marco_cabecera,
            text="Pregunta 1 de 10",
            font=self.opcion_font,
            bg="#21252b",
            fg="white"
        )
        self.lbl_num_pregunta.pack(side=tk.LEFT)
        
        # Etiqueta para puntuación
        self.lbl_puntuacion = tk.Label(
            self.marco_cabecera,
            text="Puntuación: 0/10",
            font=self.opcion_font,
            bg="#21252b",
            fg="white"
        )
        self.lbl_puntuacion.pack(side=tk.RIGHT)
        
        # Marco para la pregunta
        self.marco_pregunta = tk.Frame(self.marco_juego, bg="#21252b", padx=20, pady=20)
        self.marco_pregunta.pack(fill="x", pady=(0, 20))
        
        # Etiqueta para la pregunta
        self.lbl_pregunta = tk.Label(
            self.marco_pregunta,
            text="",
            font=self.pregunta_font,
            bg="#21252b",
            fg="#61dafb",
            wraplength=700,
            justify=tk.LEFT
        )
        self.lbl_pregunta.pack(anchor=tk.W)
        
        # Marco para las opciones
        self.marco_opciones = tk.Frame(self.marco_juego, bg="#282c34", padx=20, pady=10)
        self.marco_opciones.pack(fill="x", pady=(0, 20))
        
        # Radiobuttons para las opciones
        self.opciones_radios = []
        for i in range(3):
            radio = tk.Radiobutton(
                self.marco_opciones,
                text="",
                variable=self.respuesta_seleccionada,
                value=chr(97 + i),  # 'a', 'b', 'c'
                font=self.opcion_font,
                bg="#282c34",
                fg="white",
                selectcolor="#21252b",
                activebackground="#282c34",
                activeforeground="#61dafb"
            )
            radio.pack(anchor=tk.W, pady=10)
            self.opciones_radios.append(radio)
        
        # Marco para los botones de control
        self.marco_botones = tk.Frame(self.marco_juego, bg="#282c34", padx=20, pady=10)
        self.marco_botones.pack(fill="x", side=tk.BOTTOM)
        
        # Botón para confirmar respuesta
        self.btn_confirmar = tk.Button(
            self.marco_botones,
            text="Confirmar Respuesta",
            font=self.boton_font,
            bg="#61dafb",
            fg="#282c34",
            padx=10,
            pady=5,
            relief=tk.RAISED,
            command=self.verificar_respuesta
        )
        self.btn_confirmar.pack(side=tk.RIGHT)
    
    def mostrar_pregunta(self):
        if self.pregunta_actual < self.total_preguntas:
            pregunta_dict = self.preguntas_juego[self.pregunta_actual]
            
            # Actualizar número de pregunta
            self.lbl_num_pregunta.config(text=f"Pregunta {self.pregunta_actual + 1} de {self.total_preguntas}")
            
            # Actualizar texto de la pregunta
            self.lbl_pregunta.config(text=pregunta_dict["pregunta"])
            
            # Actualizar opciones
            for i, opcion in enumerate(pregunta_dict["opciones"]):
                self.opciones_radios[i].config(text=opcion)
            
            # Limpiar selección
            self.respuesta_seleccionada.set("")
        else:
            self.mostrar_resultado_final()
    
    def verificar_respuesta(self):
        if not self.respuesta_seleccionada.get():
            messagebox.showwarning("Aviso", "Por favor, selecciona una respuesta")
            return
        
        pregunta_dict = self.preguntas_juego[self.pregunta_actual]
        respuesta_correcta = pregunta_dict["respuesta_correcta"]
        
        if self.respuesta_seleccionada.get() == respuesta_correcta:
            self.puntuacion += 1
            resultado = "¡Correcto! +1 punto"
            color = "#4CAF50"  # Verde
        else:
            resultado = f"Incorrecto. La respuesta correcta era la opción {respuesta_correcta}"
            color = "#F44336"  # Rojo
        
        # Actualizar puntuación
        self.lbl_puntuacion.config(text=f"Puntuación: {self.puntuacion}/{self.total_preguntas}")
        
        # Mostrar mensaje de resultado
        self.mostrar_resultado(resultado, color)
    
    def mostrar_resultado(self, mensaje, color):
        # Crear ventana de resultado
        ventana_resultado = tk.Toplevel(self.root)
        ventana_resultado.title("Resultado")
        ventana_resultado.geometry("400x200")
        ventana_resultado.configure(bg="#21252b")
        ventana_resultado.transient(self.root)
        ventana_resultado.grab_set()
        
        # Centrar la ventana
        ventana_resultado.geometry("+{}+{}".format(
            self.root.winfo_x() + (self.root.winfo_width() // 2) - 200,
            self.root.winfo_y() + (self.root.winfo_height() // 2) - 100
        ))
        
        # Mostrar mensaje
        tk.Label(
            ventana_resultado,
            text=mensaje,
            font=self.pregunta_font,
            bg="#21252b",
            fg=color,
            wraplength=350,
            pady=30
        ).pack(expand=True)
        
        # Botón para continuar
        tk.Button(
            ventana_resultado,
            text="Continuar",
            font=self.opcion_font,
            bg="#61dafb",
            fg="#282c34",
            padx=10,
            pady=5,
            command=lambda: self.continuar_juego(ventana_resultado)
        ).pack(pady=20)
    
    def continuar_juego(self, ventana):
        ventana.destroy()
        self.pregunta_actual += 1
        self.mostrar_pregunta()
    
    def mostrar_resultado_final(self):
        # Eliminar marco de juego
        self.marco_juego.destroy()
        
        # Crear marco de resultados
        self.marco_resultados = tk.Frame(self.root, bg="#282c34", padx=20, pady=20)
        self.marco_resultados.pack(fill="both", expand=True)
        
        # Título
        tk.Label(
            self.marco_resultados,
            text="¡FIN DEL JUEGO!",
            font=self.titulo_font,
            bg="#282c34",
            fg="#61dafb",
            pady=20
        ).pack()
        
        # Puntuación final
        tk.Label(
            self.marco_resultados,
            text=f"Tu puntuación final: {self.puntuacion}/{self.total_preguntas}",
            font=self.pregunta_font,
            bg="#282c34",
            fg="white",
            pady=10
        ).pack()
        
        # Mensaje según el rendimiento
        if self.puntuacion == self.total_preguntas:
            mensaje = "¡Perfecto! Eres un genio de la cultura general."
            color = "#4CAF50"  # Verde
        elif self.puntuacion >= 7:
            mensaje = "¡Muy bien! Tienes buenos conocimientos generales."
            color = "#4CAF50"  # Verde
        elif self.puntuacion >= 5:
            mensaje = "No está mal, pero puedes mejorar."
            color = "#FFC107"  # Amarillo
        else:
            mensaje = "Necesitas repasar un poco más tus conocimientos de cultura general."
            color = "#F44336"  # Rojo
        
        tk.Label(
            self.marco_resultados,
            text=mensaje,
            font=self.opcion_font,
            bg="#282c34",
            fg=color,
            pady=20
        ).pack()
        
        # Botones para jugar de nuevo o salir
        marco_botones_final = tk.Frame(self.marco_resultados, bg="#282c34")
        marco_botones_final.pack(pady=20)
        
        tk.Button(
            marco_botones_final,
            text="Jugar de nuevo",
            font=self.opcion_font,
            bg="#61dafb",
            fg="#282c34",
            padx=10,
            pady=5,
            command=self.reiniciar_juego
        ).pack(side=tk.LEFT, padx=10)
        
        tk.Button(
            marco_botones_final,
            text="Salir",
            font=self.opcion_font,
            bg="#E91E63",
            fg="white",
            padx=10,
            pady=5,
            command=self.root.destroy
        ).pack(side=tk.LEFT, padx=10)
    
    def reiniciar_juego(self):
        # Eliminar marco de resultados
        self.marco_resultados.destroy()
        
        # Recrear pantalla de inicio
        self.crear_pantalla_inicio()

if __name__ == "__main__":
    root = tk.Tk()
    app = JuegoTrivia(root)
    root.mainloop()